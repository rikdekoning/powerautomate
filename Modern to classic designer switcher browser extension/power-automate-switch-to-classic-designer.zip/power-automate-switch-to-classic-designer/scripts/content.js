chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    let url = new URL(window.location.href.toString());
    // Check if v3 parameter exists and is set to true. If so, set it to false
    if (url.searchParams.has('v3', true)) {
        url.searchParams.set('v3', false);
        history.pushState({}, '', url.href);
        location.reload()
    }
    // Check if current page is a flow run and v3 is set to true or is non-existent
    else if (request.href.includes('/runs/') && (url.searchParams.has('v3', true) || (!(url.searchParams.has('v3'))))) {        
        // If v3 is already set to true, change it to false
        if (url.searchParams.has('v3', true)) {
            url.searchParams.set('v3', false);
        }
        // Otherwise, v3 is non-existent and will be added
        else {
            url.searchParams.append('v3', false);
        }
        history.pushState({}, '', url.href);
        location.reload()
    }
    // Check if current page is edit page (not details) and v3 is set to true or is non-existent
    else if ((!request.href.includes('/details')) && (url.searchParams.has('v3', true) || (!(url.searchParams.has('v3'))))) {
        // If v3 is already set to true, change it to false
        if (url.searchParams.has('v3', true)) {
            url.searchParams.set('v3', false);
        }
        // Otherwise, v3 is non-existent and will be added
        else {
            url.searchParams.append('v3', false);
        }
        history.pushState({}, '', url.href);
        location.reload()
    }
});
