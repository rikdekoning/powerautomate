let url = new URL(window.location.href.toString());
if (url.searchParams.has('v3', true)) {
    url.searchParams.set('v3', false);
    history.pushState({}, '', url.href);
    location.reload()
}